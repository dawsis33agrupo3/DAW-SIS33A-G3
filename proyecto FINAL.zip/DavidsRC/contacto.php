<div id="contact" class="contact">
    <div class="section secondary-section">
        <div class="container">
            <div class="title">
                <h1>Contact Us</h1>
                <p>¡Para más información acerca de nuestros servicios, tarifas y promociones!
Llámanos al: (503) 2535-2864 y 7889-8953
Nuestro correo: davicsrentcar@gmail.com
¡Somos tu mejor opción en renta de autos!</p>
            </div>
        </div>
        <div class="map-wrapper">

          <div class="wrapper fadeInDown">
          <aside><center><h2 style="color: white;">MAPA</h2></center><br><<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2027.3903237040244!2d-89.5581206221642!3d13.9780339780897!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x1c020dad55d41cca!2sDaniels+Tours+Rent+A+Car+Sa.+De+Cv.!5e0!3m2!1ses!2ssv!4v1559523390534!5m2!1ses!2ssv" width="1000" height="450" frameborder="0" style="border:0" allowfullscreen></iframe> </aside>
        </div>
</div>


        <div class="container">
            <div class="span9 center contact-info">
                <p>Colonia Solórzano, calle By Pass frente a tigo, (0,00 km)
                  Santa Ana (El Salvador)</p>
                <p class="info-mail">davidsrentcar@gmail.com</p>
                <p>+503 234 567 890</p>
                <p>+503 286 543 850</p>
                <div class="title">
                    <h3>Siguenos en nuestras redes</h3>
                </div>
            </div>
            <div class="row-fluid centered">
                <ul class="social">
                    <li>
                        <a href="">
                            <span class="icon-facebook-circled"></span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon-twitter-circled"></span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon-linkedin-circled"></span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon-pinterest-circled"></span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon-dribbble-circled"></span>
                        </a>
                    </li>
                    <li>
                        <a href="">
                            <span class="icon-gplus-circled"></span>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>
