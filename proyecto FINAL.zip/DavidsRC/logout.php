<?php
session_destroy();
echo "<script>location.href='index.php?pag=login.php';</script>";
 ?>
