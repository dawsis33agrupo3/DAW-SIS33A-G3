<?php
$server="localhost";
$user="root";
$pass="";
$db="davidrc";
$cn=new mysqli($server,$user,$pass,$db);
 ?>
